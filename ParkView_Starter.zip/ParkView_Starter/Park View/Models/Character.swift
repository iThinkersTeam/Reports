//
//  Character.swift
//  Park View
//
//  Created by Alex on 03.09.17.
//  Copyright © 2017 Ray Wenderlich. All rights reserved.
//

import Foundation
import MapKit

//class Character: MKCircle {
//    
//    var name: String?
//    var color: UIColor?
//    
//    convenience init(filename: String, color: UIColor) {
//        guard let points = Park.plist(filename) as? [String] else { self.init(); return }
//        
//        self.init(center: randomCenter, radius: randomRadius)
//        self.name = filename
//        self.color = color
//        
//        let cgPoints = points.map { CGPointFromString($0) }
//        let coords = cgPoints.map { CLLocationCoordinate2DMake(CLLocationDegrees($0.x), CLLocationDegrees($0.y)) }
//        
//        let randomCenter = coords[Int(arc4random()%4)]
//        let randomRadius = CLLocationDistance(max(5, Int(arc4random()%40)))
//        
//        
//    }
//}

