//
//  ViewController.swift
//  TestNLP
//
//  Created by Alex on 08.08.17.
//  Copyright © 2017 iThinkers.com.ua. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBOutlet weak var lexic: UIButton!
    
    @IBAction func lexical(_ sender: Any) {
        let tagger = NSLinguisticTagger(tagSchemes: [.lexicalClass], options: 0)
        let options: NSLinguisticTagger.Options = [.omitPunctuation, .omitWhitespace]
        
        let text = "Please click the ❤ button to get this article seen by more people."
        tagger.string = text
        
        let range = NSRange(location: 0, length: text.utf16.count)
        
        tagger.enumerateTags(in: range, unit: .word, scheme: .lexicalClass, options: options) { tag, tokenRange, stop in
            let word = (text as NSString).substring(with: tokenRange)
            print("\(tag!.rawValue):\(word)")
        }
    }
    @IBAction func language(_ sender: Any) {
        let tagger = NSLinguisticTagger(tagSchemes: [.language], options: 0)
        let text = "My company is iThinkers"
        tagger.string = text
        if let language = tagger.dominantLanguage {
            print(language)
        } else {
            print("can't get domainant language")
        }
    }
    @IBAction func token(_ sender: Any) {
        let tagger = NSLinguisticTagger(tagSchemes: [.tokenType], options: 0)
        let options: NSLinguisticTagger.Options = [.omitPunctuation, .omitWhitespace]
        
        let text = "I will show you natural language processing in iOS 11."
        tagger.string = text
        
        let range = NSRange(location: 0, length: text.utf16.count)
        tagger.enumerateTags(in: range, unit: .word, scheme: .tokenType, options: options) { tag, tokenRange, stop in
            let token = (text as NSString).substring(with: tokenRange)
            print("\(tag!.rawValue): \(token)")
            
        }
    }
    @IBAction func lemmat(_ sender: Any) {
        let tagger = NSLinguisticTagger(tagSchemes: [.lemma], options: 0)
        let options: NSLinguisticTagger.Options = [.omitPunctuation, .omitWhitespace]
        
        let text = "Сегодня классная погода. Не жарко и прохладно"
        tagger.string = text
        
        let range = NSRange(location: 0, length: text.utf16.count)
        
        tagger.enumerateTags(in: range, unit: .word, scheme: .lemma, options: options) { tag, tokenRange, stop in
            if let lemma = tag?.rawValue {
                print(lemma)
            }
        }
    }
    @IBAction func name(_ sender: Any) {
        let tagger = NSLinguisticTagger(tagSchemes: [.nameType], options: 0)
        let options: NSLinguisticTagger.Options = [.omitPunctuation, .omitWhitespace]
        let tags: [NSLinguisticTag] = [.personalName, .placeName, .organizationName]
        
        let text = "Silicon Valley is a nickname for the southern portion of the San Francisco Bay Area, in the northern part of the U.S. state of California. In 2014, tech companies Google, Yahoo!, Facebook, Apple, and others, released corporate transparency reports that offered detailed employee breakdowns. - Wikipedia"
        tagger.string = text
        
        let range = NSRange(location: 0, length: text.utf16.count)
        
        tagger.enumerateTags(in: range, unit: .word, scheme: .nameType, options: options) { tag, tokenRange, stop in
            if let tag = tag, tags.contains(tag) {
                let name = (text as NSString).substring(with: tokenRange)
                print("\(name)")
            }
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

