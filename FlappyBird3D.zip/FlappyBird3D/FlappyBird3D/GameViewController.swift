//
//  GameViewController.swift
//  FlappyBird3D
//
//  Created by Test on 09.11.17.
//  Copyright © 2017 Test. All rights reserved.
//

import UIKit
import QuartzCore
import SceneKit

class GameViewController: UIViewController {
    
    var scnView: SCNView!
    var scnScene: BirdScene!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
        setupScene()
    }
    
    func setupView() {
        scnView = self.view as! SCNView
    }
    
    func setupScene() {
        scnScene = BirdScene(create: true)
        scnView.scene = scnScene
        
        scnView.delegate = scnScene
        scnView.isPlaying = true

        scnView.backgroundColor = #colorLiteral(red: 0.4745098039, green: 0.9124348958, blue: 1, alpha: 1)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            scnScene.emptyBird.physicsBody!.velocity = SCNVector3(0, 2, 0)
            scnScene.bird.runAction(scnScene.rotationSeq)
    }
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }

}
