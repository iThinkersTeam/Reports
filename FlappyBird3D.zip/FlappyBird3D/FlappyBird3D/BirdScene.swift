//
//  BirdScene.swift
//  FlappyBird3D
//
//  Created by Test on 09.11.17.
//  Copyright © 2017 Test. All rights reserved.
//

import SceneKit

class BirdScene: SCNScene, SCNSceneRendererDelegate {
    
    let emptyGrass1 = SCNNode()
    let emptyGrass2 = SCNNode()
    
    var runningUpdate = true
    var timeLast: Double?
    let speedConstant = -0.7
    
    var emptyPipe1 = SCNNode()
    var emptyPipe2 = SCNNode()
    var emptyPipe3 = SCNNode()
    var emptyPipe4 = SCNNode()
    
    let emptyBird = SCNNode()
    var bird = SCNNode()
    
    var rotationSeq = SCNAction()
    
    convenience init(create: Bool) {
        self.init()
        
        let rotationAction1 = SCNAction.rotate(toAxisAngle: SCNVector4(1, 0, 0, 0.78), duration: 1)
        let rotationAction2 = SCNAction.rotate(toAxisAngle: SCNVector4(1, 0, 0, -1.57), duration: 1)
        rotationAction2.timingMode = .easeOut
        
        rotationSeq = SCNAction.sequence([rotationAction1, rotationAction2])
       
        setupCameraAndLights()
        setupScenery()
        
        physicsWorld.gravity = SCNVector3(0, -5.0, 0)
        
        let propsScene = SCNScene(named: "art.scnassets/Props.dae")!
        emptyGrass1.scale = SCNVector3(easyScale: 0.15)
        emptyGrass1.position = SCNVector3(0, -1.3, 0)
        
        emptyGrass2.scale = SCNVector3(easyScale: 0.15)
        emptyGrass2.position = SCNVector3(4.45, -1.3, 0)
        
        let grass1 = propsScene.rootNode.childNode(withName: "Ground", recursively: true)!
        grass1.position = SCNVector3(-5.0, 0, 0)
        
        let grass2 = grass1.clone()
        grass2.position = SCNVector3(-5.0, 0, 0)
        
        emptyGrass1.addChildNode(grass1)
        emptyGrass2.addChildNode(grass2)
        
        rootNode.addChildNode(emptyGrass1)
        rootNode.addChildNode(emptyGrass2)
        
        let bottomPipe = propsScene.rootNode.childNode(withName: "Pipe", recursively: true)!
        let topPipe = bottomPipe.clone()
        topPipe.rotation = SCNVector4(0, 0, 1, Double.pi)
        topPipe.position = SCNVector3(0, 13, 0)
        
        let emptyPipe = SCNNode()
        emptyPipe.addChildNode(bottomPipe)
        emptyPipe.addChildNode(topPipe)
        emptyPipe.scale = SCNVector3(easyScale: 0.15)
        
        emptyPipe1 = emptyPipe.clone()
        emptyPipe1.position = SCNVector3(2, randomHeight(), 0)
        
        emptyPipe2 = emptyPipe.clone()
        emptyPipe2.position = SCNVector3(3, randomHeight(), 0)
        
        emptyPipe3 = emptyPipe.clone()
        emptyPipe3.position = SCNVector3(4, randomHeight(), 0)
        
        emptyPipe4 = emptyPipe.clone()
        emptyPipe4.position = SCNVector3(5, randomHeight(), 0)
        
        rootNode.addChildNode(emptyPipe1)
        rootNode.addChildNode(emptyPipe2)
        rootNode.addChildNode(emptyPipe3)
        rootNode.addChildNode(emptyPipe4)
        
        let birdScene = SCNScene(named: "art.scnassets/FlappyBird.dae")!
        bird = birdScene.rootNode.childNode(withName: "Bird", recursively: true)!
        emptyBird.addChildNode(bird)
        emptyBird.scale = SCNVector3(easyScale: 0.08)
        emptyBird.rotation = SCNVector4(0, 1, 0, -1.57)
        emptyBird.position = SCNVector3(-0.3, 0, 0)
        
        let birdGeo = SCNSphere(radius: 0.05)

        emptyBird.physicsBody = SCNPhysicsBody(type: .dynamic, shape: SCNPhysicsShape(geometry: birdGeo, options: nil))
        emptyBird.physicsBody!.mass = 5
        emptyBird.physicsBody!.velocityFactor = SCNVector3(1,1,0)
        emptyBird.physicsBody!.angularVelocityFactor = SCNVector3Zero
        
        rootNode.addChildNode(emptyBird)
        
    }
    
    func setupCameraAndLights() {
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        cameraNode.camera!.usesOrthographicProjection = false
        cameraNode.position = SCNVector3(0, 0, 0)
        cameraNode.pivot = SCNMatrix4MakeTranslation(0, 0, -3)
        rootNode.addChildNode(cameraNode)
        
        let lightOne = SCNLight()
        lightOne.type = .spot
        lightOne.spotOuterAngle = 90
        lightOne.attenuationStartDistance = 0.0
        lightOne.attenuationFalloffExponent = 2
        lightOne.attenuationEndDistance = 30.0
        
        let lightNodeSpot = SCNNode()
        lightNodeSpot.light = lightOne
        lightNodeSpot.position = SCNVector3(0, 10, 1)
        rootNode.addChildNode(lightNodeSpot)
        
        let lightNodeFront = SCNNode()
        lightNodeFront.light = lightOne
        lightNodeFront.position = SCNVector3(0, 1, 15)
        rootNode.addChildNode(lightNodeFront)
        
        let emptyAtCenter = SCNNode()
        emptyAtCenter.position = SCNVector3Zero
        rootNode.addChildNode(emptyAtCenter)
        
        lightNodeSpot.constraints = [SCNLookAtConstraint(target: emptyAtCenter)]
        lightNodeFront.constraints = [SCNLookAtConstraint(target: emptyAtCenter)]
        cameraNode.constraints = [SCNLookAtConstraint(target: emptyAtCenter)]
        
        let ambientLight = SCNNode()
        ambientLight.light = SCNLight()
        ambientLight.light!.type = .ambient
        ambientLight.light!.color = UIColor(white: 0.05, alpha: 1.0)
        rootNode.addChildNode(ambientLight)
    }
    
    func setupScenery() {
        
        let groundGeo = SCNBox(width: 4, height: 0.5, length: 0.4, chamferRadius: 0)
        groundGeo.firstMaterial!.diffuse.contents = #colorLiteral(red: 1, green: 0.7685058713, blue: 0, alpha: 1)
        groundGeo.firstMaterial!.specular.contents = UIColor.black
        groundGeo.firstMaterial!.emission.contents = #colorLiteral(red: 0.6220703125, green: 0.3915527463, blue: 0.06076388889, alpha: 1)
        
        let groundNode = SCNNode(geometry: groundGeo)
        
        let emptySand = SCNNode()
        emptySand.addChildNode(groundNode)
        emptySand.position.y = -1.63

        rootNode.addChildNode(emptySand)
        
    }
    
    func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        let dt: Double
        
        if runningUpdate {
            if let lt = timeLast {
                dt = time - lt
            } else {
                dt = 0
            }
        } else {
            dt = 0
        }
        
        timeLast = time
        
        moveGrass(node: emptyGrass1, dt: dt)
        moveGrass(node: emptyGrass2, dt: dt)
        
        movePipe(node: emptyPipe1, dt: dt)
        movePipe(node: emptyPipe2, dt: dt)
        movePipe(node: emptyPipe3, dt: dt)
        movePipe(node: emptyPipe4, dt: dt)
    }
    
    func moveGrass(node: SCNNode, dt: Double) {
        node.position.x += Float(dt * speedConstant)
        
        if node.position.x <= -4.45 {
            node.position.x = 4.45
        }
    }
    
    func movePipe(node: SCNNode, dt: Double) {
        node.position.x += Float(dt * speedConstant)
        
        if node.position.x <= -2 {
            node.position.x = 2
            node.position.y = randomHeight()
        }
    }
    
    func randomHeight() -> Float {
        var newHeight = Float(arc4random_uniform(13))
        newHeight /= -10.0
        
        return newHeight
    }
}

extension SCNVector3 {
    
    init(easyScale: Float) {
        self.x = easyScale
        self.y = easyScale
        self.z = easyScale
    }
}






