//
//  CustomTableViewCell.swift
//  StreachableTableViewHeader
//
//  Created by Test on 27.09.17.
//  Copyright © 2017 Test. All rights reserved.
//

import UIKit

class CustomTableViewCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
