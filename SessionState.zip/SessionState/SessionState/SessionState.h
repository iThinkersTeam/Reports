//
//  SessionState.h
//  SessionState
//
//  Created by Aleksei Gordienko on 01.01.2018.
//  Copyright © 2018 Aleksei Gordienko. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SessionState.
FOUNDATION_EXPORT double SessionStateVersionNumber;

//! Project version string for SessionState.
FOUNDATION_EXPORT const unsigned char SessionStateVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SessionState/PublicHeader.h>


