//
//  SessionState.swift
//  SessionState
//

import Foundation

public class SessionState {
    
    /// In-memory storage for key-value pairs
    private var storage = [String: Any]()
    
    /// Serializes access to our internal dictionary
//    private let syncQueque = DispatchQueue(label: "Serialization Queque")
    private let asyncQueque = DispatchQueue(label: "async Queque",  attributes: .concurrent, target: nil)
    
    /// Hide initializer
    private init() { }
    
    /// Swift guarantees that lazily initialized globals or static properties are thread-sage
    /// GCD dispatch_once is not needed to create singletons,
    /// and it is not longer available in Swift3
    public static let shared: SessionState = {
        let instance = SessionState()
        return instance
    }()
    
    public func set<T>(_ value: T?, forKey key: String ) {
        asyncQueque.async(flags: .barrier) {
            if value == nil {
                if self.storage.removeValue(forKey: key) != nil {
                    print("Successfully removed value for key \(key)")
                } else { print("No value for key \(key)") }
            }
            self.storage[key] = value
        }
    }
    
    public func object<T>(forKey key: String ) -> T? {
        var result: T?
        asyncQueque.sync {
            result = storage[key] as? T ?? nil
        }
        return result
    }
}

