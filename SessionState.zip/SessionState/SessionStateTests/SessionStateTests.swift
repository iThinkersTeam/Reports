//
//  SessionStateTests.swift
//  SessionStateTests
//
//  Created by Aleksei Gordienko on 01.01.2018.
//  Copyright © 2018 Aleksei Gordienko. All rights reserved.
//

import XCTest
@testable import SessionState

class SessionStateTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testConcurrentAccess() {
        let asyncQueque = DispatchQueue(label: "asyncQueque", attributes: .concurrent, target: nil)
        
        let expect = expectation(description: "Storing values in SessionState shall succeed")
        
        let MaxIndex = 200
        
        for index in 0...MaxIndex {
            asyncQueque.async {
                SessionState.shared.set(index, forKey: String(index))
            }
        }
        
        while SessionState.shared.object(forKey: String(MaxIndex)) != MaxIndex {
            // nop
        }
        
        expect.fulfill()
        
        waitForExpectations(timeout: 10) { (error) in
            XCTAssertNil(error, "Test expectation failed")
        }
    }

    
}
