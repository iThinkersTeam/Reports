//
//  definitions.swift
//  AdvancedUIKitAnimations
//
//  Created by Ignacio Nieto Carvajal on 11/7/17.
//  Copyright © 2017 Digital Leaves. All rights reserved.
//

import UIKit

let kTopMarginSpan: CGFloat = 0.6
