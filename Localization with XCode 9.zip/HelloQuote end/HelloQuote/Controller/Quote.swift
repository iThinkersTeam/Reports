//
//  Quote.swift
//  HelloQuote
//
//  Created by User on 01.08.17.
//  Copyright © 2017 User. All rights reserved.
//

import UIKit

class Quote: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
      
      quoteLabel.text = NSLocalizedString("To succeed, we must first believe that we can. ", comment: "Quote that quote")
      
      authorLabel.text = NSLocalizedString("Michael Korda", comment: "Author Authority")

    }

  @IBOutlet weak var quoteLabel: UILabel!

  @IBOutlet weak var authorLabel: UILabel!

}
